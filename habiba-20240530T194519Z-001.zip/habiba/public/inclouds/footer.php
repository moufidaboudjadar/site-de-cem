
<footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Madrassati 2024</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Tel: (+213)06666666666</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Fax (+213) 038 66 55 44</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">mail@gmail.com</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="contact.php">Contact</a>
                    </div>
                </div>
            </div>
        </footer>